echo installing ftpbckp \n

echo please enter root password \n

su

echo cpying files

cp ./ftpbckp.exp /usr/bin/
cp ./tree /usr/bin/

echo done ..
echo you can start using ftpbckup
echo Enjoy ! 
echo Autor :  saber zrelli ( saber_z@fastmail.fm )
